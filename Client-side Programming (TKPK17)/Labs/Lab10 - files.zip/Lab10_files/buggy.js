// ************************
//  HTML element variables
//***********************
var inputWord = document.getElementByID("word");
var outputWord = document.getElementByID("results")
var btn = document.getElementByID("button");


// ****************************
//  Event Listener for button
//**************************
btn.addEventListener("click", removeS);


// *************************************************
//  Function called by the event listener on click
//********************************************
function removeS() {

  if (notEmpty(inputWord)) {
    var wordArray = string2array(inputWord.value);
    for (var i = 0; i < wordArray.length; i++) {
      if(wordArray[i].toLowerCase() === "s"){
        wordArray.splice(i,1); // see reference below
      }
    }
    outputWord.innerText = array2string(wordArray);
  } else {
    inputWord.placeholder = "Type a word here"
  }
}


// *****************************************
//  Function to check if a string is empty
//************************************
function notEmpty(input) {
  if (input === "") {
    return false;
  } else {
    return true;
  }
}


// ************************************************
//  Function that converts a string into an array
//********************************************
function string2array(input) {
  return input.split("");
}


// ************************************************
//  Function that converts an array into a string
//********************************************
function array2string(input) {
  return input.join("-");
}

// *****************************
//  array.splice(index, items-to-remove)
//*****************************
/*
if...
var myArray = [10,11,12,13,"bad",14] ,
and we want to remove the item "bad",
we can use splice() to alter the array.

The item "bad" is currently at index 4,
meaning we could access it by myArray[4].

Since it's not in the beginning or at
the end of the array we cannot use pop()
or shift() to remove it.

splice takes 2 arguments;
The index from where we want to start removing items
And the amount of items to remove.

Since we only want to remove one item at index 4
calling myArray.splice(4,1) will remove "bad" from array.

myArray is now[10,11,12,13,14]
*/
