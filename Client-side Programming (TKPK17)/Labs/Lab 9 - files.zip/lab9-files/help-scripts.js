/*
This solution will only work if your ball- and paddle objects have these
variable-, property- and method names and that they have the
functionality as my objects. For that reason
I'm pasting those as well,
for reference,
below.
*/


// *******************************
//  control the paddle with mouse
//*****************************
canvas.addEventListener("mousemove", function move(event) {
    mouseX = event.clientX - this.offsetLeft;
    paddle.move(mouseX);
});


// ************************
//  paddle collision test
//**********************
function paddleHit() {
    // all these variables are just to make the if statement easier to understand
    var ballBottom = ball.y + ball.h;
    var ballCenterX = ball.x + ball.w/2;
    var paddleTop = paddle.y;
    var paddleCenterX = paddle.x + paddle.w/2;
    var centerDistance = Math.abs(ballCenterX - paddleCenterX); // might be negative. Math.abs() will fix that
    var touchDistance = ball.w/2 + paddle.w/2;

    if (ballBottom >= paddleTop && centerDistance <= touchDistance) {
        // collision detected!
        ball.y = paddle.y - ball.h; // rescue ball that hit paddle on the side. put it back on top of paddle
        ball.dy *= -1;
    }
}
// To understand my collision test, play around with this codepen: http://codepen.io/jkohlin/pen/RpzWXv?editors=1010

// *****************************
//  This function assumes you have a ball object called 'ball'.
//  It also assumes you call this function by passing in a 'brick object' to test collision with
//*****************************
function brickHit(brick) {
    var ballCenterX = ball.x + ball.w/2;
    var ballCenterY = ball.y + ball.h/2;
    var brickCenterX = brick.x + brick.w/2;
    var brickCenterY = brick.y + brick.h/2;
    var touchDistanceX = ball.w/2 + brick.w/2; // if center of ball and center of brick is closer than this, its a collision
    var touchDistanceY = ball.h/2 + brick.h/2;
    var centerDistanceX = Math.abs(ballCenterX - brickCenterX); // Math.abs() returns an absolute number i.e. negative numbers become positive
    var centerDistanceY = Math.abs(ballCenterY - brickCenterY);

    if (centerDistanceX <= touchDistanceX && centerDistanceY <= touchDistanceY){
        /*
        if, we reached this line,
        we got a hit on one side with one brick.
        Now it's up to you to decide what should
        happen (other than changing dx and/or dy).
        Destroying bricks and playing sound is your problem.

        The following rows will decide if it was a
        vertical hit or a horizontal hit and act acordingly.
        */
        if (centerDistanceY < centerDistanceX) { // vertical hit. Bounce left or right.
            ball.dx *= -1;
        }
        if (centerDistanceX < centerDistanceY ) {// horizontal hit. Bounce up or down.
            ball.dy *= -1;
        }
        if (centerDistanceX === centerDistanceY) { //hitting a corner
            ball.dx *= -1;
            ball.dy *= -1;
        }
    }
}



// ****************
//  Paddle object
//**************
var paddle = {
    w: 80,
    h: 20,
    x: canvas.width / 2 - 40,
    y: canvas.height - 40,
    draw: function() {
        ctx.fillRect(this.x, this.y, this.w, this.h);
    },
    move: function(mouseX) {
        this.x = mouseX - this.w / 2;
    }
}



// **************
//  ball object
//************
var ball = {
    w: 10,
    h: 10,
    x: canvas.width / 2 - 5,
    y: canvas.height - 50,
    dx: 1,
    dy: -1,
    speed: 2,
    move: function() {
        this.wallBounce()
        this.x += this.speed * this.dx;
        this.y += this.speed * this.dy;
    },
    draw: function() {
        ctx.fillRect(this.x, this.y, this.w, this.h);
    }
}
