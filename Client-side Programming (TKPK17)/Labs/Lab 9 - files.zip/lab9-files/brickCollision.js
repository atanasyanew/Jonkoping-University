
// *****************************
//  This function assumes you have a ball object called 'ball'.
//  It also assumes you call this function by passing in a 'brick object' to test collision with
//*****************************

function brickHit(brick) {
    var ballCenterX = ball.x + ball.w/2;
    var ballCenterY = ball.y + ball.h/2;
    var brickCenterX = brick.x + brick.w/2;
    var brickCenterY = brick.y + brick.h/2;
    var touchDistanceX = ball.w/2 + brick.w/2; // if center of ball and center of brick is closer than this, its a collision
    var touchDistanceY = ball.h/2 + brick.h/2;
    var centerDistanceX = Math.abs(ballCenterX - brickCenterX); // Math.abs() returns an absolute number i.e. negative numbers become positive
    var centerDistanceY = Math.abs(ballCenterY - brickCenterY);

    if (centerDistanceX <= touchDistanceX && centerDistanceY <= touchDistanceY){
        /*
        if, we reached this line,
        we got a hit on one side with one brick.
        Now it's up to you to decide what should
        happen (other than changing dx and/or dy).
        The following row will decide if it was a
        vertical hit or a horizontal hit and act acordingly.
        Destroying bricks and playing sound is your problem.
        */
        if (centerDistanceY < centerDistanceX) { // vertical hit. Bounce left or right.
            ball.dx *= -1;
        }
        if (centerDistanceX < centerDistanceY ) {// horizontal hit. Bounce up or down.
            ball.dy *= -1;
        }
        if (centerDistanceX === centerDistanceY) { //hitting a corner
            ball.dx *= -1;
            ball.dy *= -1;
        }
    }
}
