var canvas = document.getElementById("stage");
