var secretObject = {
    note:"if I tell you this,you must promise to keep it a secret. Are you up for the challenge? If that is the case then that would be: awesome!",
    list: [{cue:",", sequence:3}, {cue:".", sequence:4}, {cue:":", sequence:9}]
};

function noMoreSecrets(secret) {
    // declare secretMessage as an empty string;
    // loop through the secret note
        // loop through the secret list
            // if the character at the current index in the secret note is the same as the cue-character in the current object of the list array
                // step forward in the secret note and copy as many characters as the sequence says, one by one to the end of the secretMessage variable

    return secretMessage;
}

noMoreSecrets(secretObject);
