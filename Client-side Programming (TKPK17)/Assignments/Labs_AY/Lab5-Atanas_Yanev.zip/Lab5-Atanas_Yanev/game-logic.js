var answer = Math.floor(Math.random()*10)+1;
var score = 0;
var guessCount = 10;
var parent = document.getElementById("ballsContainer");


function playGame() {
  event.preventDefault();
    
  var guess = Number(document.getElementById("guessBox").value);
    
  console.log("Your guess is " + String(guess));
    
  answer = Math.floor(Math.random()*10)+1;
    
  if(guess > 0 && guess <= 10) 
  {
    if(guess <= answer) {
        
        score = score + guess; 
        
    }
      
    guessCount = guessCount-1;
    document.getElementById("score").innerText = score;
    document.getElementById("guessCount").innerText = guessCount;
  }
    
  else 
  {
    console.log("Wrong value! Try a number between 1 and 10.");
  }
    
  parent.innerHTML = "";
    
  for (var i = 1; i <= answer; i++) 
  {
    var tempLi = document.createElement("li");
    tempLi.id  = "ball";
    parent.appendChild(tempLi);
  }
    
  document.getElementById("guessBox").value = "";
    
  if(guess == answer) 
  {
      
    console.log("Correct! Your guess is " + String(guess));
      
  }
    
  if(guessCount == 0) 
  {
    console.log("Game over. Your final score is " + String(score));
    document.getElementById("form").removeEventListener("submit", playGame);
    document.body.removeChild(document.getElementById("form"))
    
  }
}

document.getElementById("form").addEventListener("submit", playGame);