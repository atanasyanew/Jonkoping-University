﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Service.Models;

namespace ProjectManager.Controllers
{
    public class AddController : Controller
    {
        public ActionResult AddObject(string select)
        {
            switch (select)
            {
                case "1": //Add department
                    return RedirectToAction("AddDepartment");
                case "2": //Add employee
                    return RedirectToAction("AddEmployee");
                case "3": // Add project
                    return RedirectToAction("AddProject");
                default:
                    ViewBag.Error = "Could not perform the add action";
                    break;
            }
            return View("Error");
        }

        /**************************** Department methods  **************************/
        public ViewResult AddDepartment()
        {
            return View(Employee.getEmployees());
        }

        [HttpPost]
        public RedirectToRouteResult AddDepartment(string name, string bossid)
        {
            Department depObj = new Department();
            depObj.name = name;
            depObj.bossid = Convert.ToInt32(bossid);
            Department.addDepartment(depObj);
            return RedirectToAction("ListDepartments", "UserLists");
        }

        /**************************** Employee methods  **************************/
        public ActionResult AddEmployee()
        {
            return View();
        }


        /**************************** Project methods  **************************/
        public ActionResult AddProject()
        {
            return View();
        }

	}
}