﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using ProjectManager.Models;
using Service.Models;

namespace ProjectManager.Controllers
{
 //   [OutputCacheAttribute(VaryByParam = "*", Duration = 0, NoStore = true)]
    public class UserListsController : Controller
    {

        /**************************** Department methods  **************************/
        public ViewResult ListDepartments()
        {
            ViewBag.ActionType = "1";
            return View("TheListOfDepartments", Department.getDepartments());
        }

        //Using the combined class DepartmentBoss and a strongly typed view
        public ActionResult ShowDepartmentAndBoss(string bossid, string depid)
        {
            Employee empObj = Employee.getEmployee(Convert.ToInt32(bossid));
            Department depObj = Department.getDepartment(Convert.ToInt32(depid));
            if (empObj != null && depObj != null)
            {
                DepartmentBoss depBossObj = new DepartmentBoss { depid = depObj.depid, name = depObj.name, bossid = depObj.bossid, bossName = empObj.name, salary = empObj.salary};
                return View(depBossObj);
            }            
            return null;
        }

        //Alternativ using to strongly typed partial views
        public ActionResult ShowDepartmentAndBossSecond(string id)
        {
            ViewBag.ActionType = "11";
            ViewBag.Departmentid = id;
            ViewBag.Employeeid = Department.getDepartment(Convert.ToInt32(id)).bossid;
            List<Employee> departmentEmployeeList = Department.getDepartmentEmployees(Convert.ToInt32(id));
            return View(departmentEmployeeList);
        }

        [ChildActionOnly]
        public ActionResult ShowDepartmentPartial(string depid)
        {
            Department depObj = Department.getDepartment(Convert.ToInt32(depid));
            if (depObj != null)
                return PartialView(depObj);
            return null;
        }

        [ChildActionOnly]
        public ActionResult ShowEmployeePartial(string empid)
        {
            Employee empObj = Employee.getEmployee(Convert.ToInt32(empid));
            if (empObj != null)
                return PartialView(empObj);
            return null;
        }

        /**************************** Employee methods  **************************/

        public ActionResult ListEmployee()
        {
            ViewBag.ActionType = "2";
            return View(Employee.getEmployees());
        }


        /**************************** Project methods  **************************/

        public ActionResult ListProject()
        {
            ViewBag.ActionType = "3";
            return View();
        }
  	}

}