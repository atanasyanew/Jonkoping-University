﻿using BusinnesLogicLayer.Managers;
using BusinnesLogicLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApi.ControllersApi{
	public class HumansController : ApiController {
		
		public HttpResponseMessage GetByPage(int page) {
			
			var humanManager = new HumanManager();

			var humansOnCurrentPage = humanManager.GetHumansByPage(page);

			if(humansOnCurrentPage == null) {
				return Request.CreateErrorResponse(
					HttpStatusCode.NotFound,
					"invalidPageNumber"
				);
			}

			return Request.CreateResponse(humansOnCurrentPage);

		}

		public Human GetById(int id) {
			
			var humanManager = new HumanManager();

			var human = humanManager.GetHumanById(id);

			if(human == null) {
				throw new HttpResponseException(
					Request.CreateErrorResponse(
						HttpStatusCode.NotFound,
						"unknownId"
					)
				);
			}
			
			return human;

		}
		
	}
}
