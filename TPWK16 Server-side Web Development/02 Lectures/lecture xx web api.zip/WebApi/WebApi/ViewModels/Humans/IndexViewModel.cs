﻿using BusinnesLogicLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApi.ViewModels.Humans {
	public class IndexViewModel {
		public IEnumerable<Human> HumansOnCurrentPage { get; set; }
		public int NumberOfPages { get; set; }
		public int CurrentPage { get; set; }
	}
}