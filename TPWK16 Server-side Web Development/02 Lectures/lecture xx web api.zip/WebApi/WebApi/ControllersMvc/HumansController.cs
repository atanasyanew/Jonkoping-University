﻿using BusinnesLogicLayer.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApi.ViewModels.Humans;

namespace WebApi.ControllersMvc {

	public class HumansController : Controller {

		public ActionResult Index(int page = 1) {

			var humanManager = new HumanManager();

			var viewModel = new IndexViewModel {
				HumansOnCurrentPage = humanManager.GetHumansByPage(page),
				NumberOfPages = humanManager.GetNumberOfPages(),
				CurrentPage = page
			};

			return View(viewModel);

		}

		public ActionResult Show(int id) {

			var humanManager = new HumanManager();

			var human = humanManager.GetHumanById(id);

			return View(human);

		}

	}

}