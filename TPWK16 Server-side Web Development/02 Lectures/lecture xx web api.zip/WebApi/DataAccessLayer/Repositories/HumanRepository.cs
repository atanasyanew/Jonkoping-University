﻿using DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DataAccessLayer.Repositories {
	
	public class HumanRepository {
		
		// Fake database.
		private static List<Human> humans = new List<Human> {
			new Human( 1, "Alice", 10),
			new Human( 2, "Bob", 15),
			new Human( 3, "Cecilia", 20),
			new Human( 4, "David", 25),
			new Human( 5, "Eloise", 30),
			new Human( 6, "Frank", 35),
			new Human( 7, "Gabriella", 40),
			new Human( 8, "Hannes", 45),
			new Human( 9, "Ingalill", 50),
			new Human(10, "Johanna", 55),
			new Human(11, "Kurt", 60),
			new Human(12, "Lisbet", 65),
			new Human(13, "Mats", 70),
			new Human(14, "Nora", 75)
		};

		// Returns the number of humans that exists.
		public int GetNumberOfHumans() {
			return humans.Count;
		}

		// Returns the human with the given ID, or null.
		public Human GetHumanById(int id) {
			return humans.FirstOrDefault(h => h.Id == id);
		}
		
		// Order the humans by their id and then returns
		// the first NUMBERTOTAKE that comes after the first NUMBERTOSKIP,
		// or null, if NUMBERTOSKIP < 0 or NUMBERTOTAKE < 0.
		public IEnumerable<Human> GetHumans(int numberToSkip, int numberToTake) {
			
			if(numberToSkip < 0 || numberToTake < 0) {
				return null;
			}
			
			return humans.OrderBy(h => h.Id).Skip(numberToSkip).Take(numberToTake);

		}
		
	}

}