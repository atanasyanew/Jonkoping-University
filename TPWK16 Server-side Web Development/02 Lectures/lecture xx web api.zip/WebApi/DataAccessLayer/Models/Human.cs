﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DataAccessLayer.Models {
	
	public class Human {
		
		public int Id { get; set; }
		public string Name { get; set; }
		public int Age { get; set; }

		public Human(int id, string name, int age) {
			Id = id;
			Name = name;
			Age = age;
		}

	}

}