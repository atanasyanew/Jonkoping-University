﻿using BusinnesLogicLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccessLayer.Repositories;

namespace BusinnesLogicLayer.Managers {
	public class HumanManager {
		
		// Returns the human with the given ID, or null.
		public Human GetHumanById(int id) {
			
			var humanRepository = new HumanRepository();

			var human = humanRepository.GetHumanById(id);

			if(human == null) {
				return null;
			} else {
				return new Human(human);
			}

		}

		// Order the humans by their id, slices them up on different pages
		// (first page is 1, Constants.RECORDS_PER_PAGE defines humans per page)
		// and returns the humans on the given PAGE,
		// or null, if PAGE is < 1.
		public IEnumerable<Human> GetHumansByPage(int page) {
			
			if(page < 1) {
				return null;
			}
			
			var humanRepository = new HumanRepository();

			int numberToSkip = (page - 1) * Constants.RECORDS_PER_PAGE;
			int numberToTake = Constants.RECORDS_PER_PAGE;

			return humanRepository.GetHumans(numberToSkip, numberToTake).Select(
				h => new Human(h)
			);
			
		}

		// Returns the number of pages that exist when
		// Constants.RECORDS_PER_PAGE humans are shown on each page.
		public int GetNumberOfPages() {

			var humanRepository = new HumanRepository();

			return (int) Math.Ceiling(
					humanRepository.GetNumberOfHumans() /
					(double) Constants.RECORDS_PER_PAGE
			);

		}

	}
}