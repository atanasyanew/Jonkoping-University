﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BusinnesLogicLayer.Models {
	public class Human {
		
		public int Id { get; set; }
		public string Name { get; set; }
		public int Age { get; set; }

		public Human() {
			
		}

		public Human(DataAccessLayer.Models.Human human) {
			Id = human.Id;
			Name = human.Name;
			Age = human.Age;
		}

	}
}