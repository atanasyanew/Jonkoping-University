﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Service.Models;

namespace ProjectManager.Controllers
{
    public class AddController : Controller
    {
        public ActionResult AddObject(string select)
        {
            switch (select)
            {
                case "1": //Add department
                    return RedirectToAction("AddDepartment");
                case "2": //Add employee
                    return RedirectToAction("AddEmployee");
                case "3": // Add project
                    return RedirectToAction("AddProject");
                default:
                    ViewBag.Error = "Could not perform the add action";
                    break;
            }
            return View("Error");
        }

        /**************************** Department methods  **************************/
        public ViewResult AddDepartment()
        {
            Department depObj = new Department();
            ViewBag.DepartmentEmployees = new List<Employee>();
            ViewBag.NonDepartmentEmployees = Employee.getNonDepartmentEmployees();
            
            return View(depObj);
        }

        public ActionResult SelectDepartmentEmployees(List<string> SelectedEmployees, List<string> DepartmentEmployees)
        {
            /* 
             * This action method makes possible to move employees between two listboxes
             * One listbox for employees not belonging to a department, 
             * A second listbox for the selected employees to the department
             * Selected (multiselect in both boxes possible) employees are moved in both directions
             * This is pure controller-view management since no business-logic or storage is involved 
            */
            Department depObj = new Department();
            List<string> nonEmpListStr = (List<string>)TempData["NonDepartmentEmployees"];
            List<string> departmentEmployeesStr = (List<string>)TempData["DepartmentEmployees"];
            List<Employee> allEmpList = Employee.getEmployees();
            List<Employee> nonEmpList = new List<Employee>();
            List<Employee> departmentEmpList = new List<Employee>();
            nonEmpListStr.ForEach(x => nonEmpList.Add(allEmpList.Find(y => y.empid == Convert.ToInt32(x))));
            departmentEmployeesStr.ForEach(x => departmentEmpList.Add(allEmpList.Find(y => y.empid == Convert.ToInt32(x))));
            if (SelectedEmployees != null)
            {
                SelectedEmployees.ForEach(x => departmentEmpList.Add(allEmpList.Find(y => y.empid == Convert.ToInt32(x))));
                SelectedEmployees.ForEach(x => nonEmpList.RemoveAt(nonEmpList.FindIndex(y => y.empid == Convert.ToInt32(x))));
            }
            if (DepartmentEmployees != null)
            {
                DepartmentEmployees.ForEach(x => nonEmpList.Add(allEmpList.Find(y => y.empid == Convert.ToInt32(x))));
                DepartmentEmployees.ForEach(x => departmentEmpList.RemoveAt(departmentEmpList.FindIndex(y => y.empid == Convert.ToInt32(x))));
            }

            //Store the two lists of employee objects in viewbag in order to transfer to the view
            ViewBag.NonDepartmentEmployees = nonEmpList;
            ViewBag.DepartmentEmployees = departmentEmpList;

            return View("AddDepartment", depObj);
        }

        [HttpPost]
        public RedirectToRouteResult AddDepartment(string name, string bossid)
        {
            Department depObj = new Department();
            depObj.name = name;
            depObj.bossid = Convert.ToInt32(bossid);
            TempData["NonDepartmentEmployees"] = TempData["NonDepartmentEmployees"];
            TempData["DepartmentEmployees"] = TempData["DepartmentEmployees"];
            return RedirectToAction("StoreDepartment", depObj);
        }

        public RedirectToRouteResult StoreDepartment(Department depObj)
        {
            //Saves the edited data from the EditDepartment view to the database
            Department.addDepartment(depObj, (List<string>)TempData["NonDepartmentEmployees"], (List<string>)TempData["DepartmentEmployees"]);
            return RedirectToAction("ListDepartments", "UserLists");
        }

        /**************************** Employee methods  **************************/
        public ActionResult AddEmployee()
        {
            Employee empObj = new Employee();
            ViewBag.Departments = Department.getDepartments();

            return View(empObj);
        }

        [HttpPost]
        public RedirectToRouteResult AddEmployee(Employee empObj)
        {
            return RedirectToAction("StoreEmployee", empObj);
        }

        public RedirectToRouteResult StoreEmployee(Employee empObj)
        {
            Employee.addEmployee(empObj);
            return RedirectToAction("ListEmployee","UserLists");
        }
        /**************************** Project methods  **************************/
        public ActionResult AddProject()
        {
            return View();
        }

	}
}