﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Service.Models;

namespace ProjectManager.Controllers
{
    public class EditController : Controller
    {
        public ActionResult EditObject(string select, string selectid)
        {
            switch (select)
            {
                case "11": //Edit department
                    Session["DepartmentId"] = Convert.ToInt32(selectid);
                    return RedirectToAction("EditDepartment");
                case "12": //Edit employee
                    Session["EmployeeId"] = Convert.ToInt32(selectid);
                    return RedirectToAction("EditEmployee");
                case "13": // Edit project
                    return RedirectToAction("EditProject");
                default:
                    ViewBag.Error = "Could not perform the edit action";
                    break;
            }
            return View("Error");
        }

        /**************************** Department methods  **************************/
        public ViewResult EditDepartment()
        {
            Department depObj = null;
            //Initialises the data in the view by reading from the database
            depObj = Department.getDepartment((int)Session["DepartmentId"]);
            ViewBag.DepartmentEmployees = Employee.getDepartmentEmployees((int)Session["DepartmentId"]);
            Session["ControllerType"] = "Edit";
            ViewBag.NonDepartmentEmployees = Employee.getNonDepartmentEmployees();            
            return View(depObj);
        }

        [HttpPost] 
        public ViewResult SelectDepartmentEmployees(List<string> SelectedEmployees, List<string> DepartmentEmployees)
        {
            /* 
             * This action method makes possible to move employees between two listboxes
             * One listbox for employees not belonging to a department, 
             * A second listbox for the selected employees to the department
             * Selected (multiselect in both boxes possible) employees are moved in both directions
             * This is pure controller-view management since no business-logic or storage is involved 
            */
            Department depObj = Department.getDepartment((int)Session["DepartmentId"]);

            List<string> nonEmpListStr = (List<string>)TempData["NonDepartmentEmployees"];
            List<string> departmentEmployeesStr = (List<string>) TempData["DepartmentEmployees"];
            List<Employee> allEmpList = Employee.getEmployees();
            List<Employee> nonEmpList = new List<Employee>();
            List<Employee> departmentEmpList = new List<Employee>();
            nonEmpListStr.ForEach(x => nonEmpList.Add(allEmpList.Find(y => y.empid == Convert.ToInt32(x))));
            departmentEmployeesStr.ForEach(x => departmentEmpList.Add(allEmpList.Find(y => y.empid == Convert.ToInt32(x))));
            if(SelectedEmployees != null)
            {
                SelectedEmployees.ForEach(x => departmentEmpList.Add(allEmpList.Find(y => y.empid == Convert.ToInt32(x))));
                SelectedEmployees.ForEach(x => nonEmpList.RemoveAt(nonEmpList.FindIndex(y => y.empid == Convert.ToInt32(x))));
            }
            if(DepartmentEmployees != null)
            {
                DepartmentEmployees.ForEach(x => nonEmpList.Add(allEmpList.Find(y => y.empid == Convert.ToInt32(x))));
                DepartmentEmployees.ForEach(x => departmentEmpList.RemoveAt(departmentEmpList.FindIndex(y => y.empid == Convert.ToInt32(x))));
            }

            //Store the two lists of employee objects in viewbag in order to transfer to the view
            ViewBag.NonDepartmentEmployees = nonEmpList;
            ViewBag.DepartmentEmployees = departmentEmpList;

            return View("EditDepartment",depObj);
        }

       [HttpPost]
        public RedirectToRouteResult EditDepartment(Department depObj)
        {
            //Retrieves the data from the EditDepartment view 
            TempData["NonDepartmentEmployees"] = TempData["NonDepartmentEmployees"];
            TempData["DepartmentEmployees"] = TempData["DepartmentEmployees"];
            return RedirectToAction("StoreDepartment", depObj);
        }

        public RedirectToRouteResult StoreDepartment(Department depObj)
        {
            //Saves the edited data from the EditDepartment view to the database
            Department.updateDepartment(depObj, (List<string>) TempData["NonDepartmentEmployees"], (List<string>) TempData["DepartmentEmployees"]);
            return RedirectToAction("ListDepartments", "UserLists");
        }

        /**************************** Employee methods  ****************************/
        public ActionResult EditEmployee()
        {
            Employee empObj = Employee.getEmployee((int)Session["EmployeeId"]);
            ViewBag.Departments = Department.getDepartments();
            return View(empObj);
        }

        [HttpPost]
        public RedirectToRouteResult EditEmployee(Employee empObj)
        {
            return RedirectToAction("StoreEmployee", empObj);
        }

        public ActionResult StoreEmployee(Employee empObj)
        {
            if (Employee.updateEmployee(empObj))
            {
                return RedirectToAction("ListEmployee", "UserLists");
            }
            else
            {
                ViewBag.Error = "Could not save employee! Check if employee is manager of other department.";
                return View("Error");
            }
        }

        /**************************** Project methods  *****************************/
        public ActionResult EditProject()
        {
            return View();
        }
	}
}
