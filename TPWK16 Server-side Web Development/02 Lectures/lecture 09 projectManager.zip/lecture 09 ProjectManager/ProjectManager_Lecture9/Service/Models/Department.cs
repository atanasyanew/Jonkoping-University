﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Service.Mockups;
using Repository;
using Repository.Support;
using AutoMapper;
using Service.Configuration;

namespace Service.Models
{
    public class Department
    {
        public int depid { get; set; }
        public string name {get; set;}
        public int? bossid {get; set;}
        public List<Employee> depEmployeeList { get; set; }

        static private DepartmentDba _departmentDba = new DepartmentDba(); 

        static public Department getDepartment(int depId)
        {
            Department depObj = Mapper.Map<Department>(_departmentDba.Read(depId));
            depObj.depEmployeeList = Department.getDepartmentEmployees(depId);
            return depObj;
        }

        static public List<Department> getDepartments()
        {
            return Mapper.Map<List<department>, List<Department>>( _departmentDba.List());
        }

        static public List<Employee> getDepartmentEmployees(int depId)
        {
            return Employee.getDepartmentEmployees(depId);
        }

        static public void nullifyEmployeeRef(Employee empObj)
        {
            Department depObj = getDepartment((int) empObj.depid);
            depObj.bossid = null;
            _departmentDba.Update(Mapper.Map<department>(depObj));
        }

        static public void addDepartment(Department depObj, List<string> nonDepEmpList, List<string> depEmpList)
        {
            depObj.depid = _departmentDba.Add(Mapper.Map<department>(depObj));
            Employee.updateDepartmentEmployees(depObj, nonDepEmpList, depEmpList);
        }

        static public void updateDepartment(Department depObj, List<string> nonDepEmpList, List<string> depEmpList)
        {
            Employee.updateDepartmentEmployees(depObj, nonDepEmpList, depEmpList);
            _departmentDba.Update(Mapper.Map<department>(depObj));
        }

        static public void deleteDepartment(Department depObj)
        {
            /* 
             * Deletion of department requires to resolve one issue:
             * People belonging to that department, (foreign key depid in Employee table)
            */
            Employee.nullifyDepartmentRef(depObj);
            _departmentDba.Delete(Mapper.Map<department>(depObj));
        }

        static public bool isDepartmentManager(int empid)
        {
            return (Department.getDepartments().Find(x => x.bossid == empid) != null);
        }
    }
}