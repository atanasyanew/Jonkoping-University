﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;  //Required for the update method

namespace Repository.Support
{
    public class EmployeeDba
    {
        public EmployeeDba() { }

        public EmployeeDba(int depId)
        {
            _employeeObj = this.Read(depId);
        }

        private employee _employeeObj;

        public employee EmployeeObj { get { return _employeeObj; } }

        public List<employee> List()
        {
            using (var db = new dbprojectengEntities())
            {
                return db.employees.ToList();
            }
        }

        public employee Read(int id)
        {
            using (var db = new dbprojectengEntities())
            {
                return db.employees.Find(id);
            }
        }

        public List<employee> ReadDepEmp(int depId)
        {
            using (var db = new dbprojectengEntities())
            {
                return db.employees.ToList().FindAll(x => x.depid == depId);
            }
        }

       public void Add(employee empObject)
        {
            using (var db = new dbprojectengEntities())
            {
                using (var transaction = db.Database.BeginTransaction()) // Start a transaction
                {
                    empObject.empid = (db.employees.ToList().Max(x => x.empid) + 1);  //Retrieve next depid
                    db.employees.Add(empObject);  // Prepare query  
                    db.SaveChanges();   // Run the query
                    transaction.Commit();   //  Permanent the result, writing to disc and closing transaction
                }
            }
        }

        public void Update(employee empObject)
        {
            using (var db = new dbprojectengEntities())
            {
                if (empObject != null && empObject.empid > 0)
                {
                    db.employees.Attach(empObject);
                    db.Entry(empObject).State = EntityState.Modified;
                    db.SaveChanges();
                }
            }
        }

        public void Delete(employee empObject)
        {
            using (var db = new dbprojectengEntities())
            {
                employee empItem = db.employees.Find(empObject.empid);
                db.employees.Remove(empItem);
                db.SaveChanges();
            }
        }

    }
}
