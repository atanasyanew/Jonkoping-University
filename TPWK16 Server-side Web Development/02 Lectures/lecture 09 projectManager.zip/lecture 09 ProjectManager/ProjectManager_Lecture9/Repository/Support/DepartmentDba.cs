﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;  //Required for the update method

namespace Repository.Support
{
    public class DepartmentDba
    {
        public DepartmentDba() { }

        public DepartmentDba(int depId)
        {
            _departmentObj = this.Read(depId);
        }

        private department _departmentObj;

        public department DepartmentObj { get { return _departmentObj;} }

        public List<department> List()  //Retrieves all departments
        {
            using(var db = new dbprojectengEntities())
            {
                // return db.departments.ToList();
                //var query = from dep in db.departments orderby dep.name select dep;
                var query = db.departments.OrderBy(x => x.name);
                return query.ToList(); 
            }
        }

        public department Read(int id)  //Finds a particular "department"
        {
            using (var db = new dbprojectengEntities())
            {
                db.departments.Load();
                return db.departments.Find(id); 
                
                // var query = from dep in db.departments where (dep.depid == id) select dep;
 
                // var query = db.departments.Where(x => x.depid == id);

                //return query.SingleOrDefault();
            }
        }

        public int Add(department depObject)
        {
            int newDepId = 0;
            using (var db = new dbprojectengEntities())
            {
                using (var transaction = db.Database.BeginTransaction()) // Start a transaction
                {
                    db.departments.Load();
                    newDepId = depObject.depid = (db.departments.ToList().Max(x => x.depid) + 1);  //Retrieve next depid
                    db.departments.Add(depObject);  // Prepare query  
                    db.SaveChanges();   // Run the query
                    transaction.Commit();   //  Permanent the result, writing to disc and closing transaction
                }
            }
            return newDepId;
        }

        public void Update(department depObject)
        {
            using (var db = new dbprojectengEntities())
            {
                db.departments.Attach(depObject);
                db.Entry(depObject).State = EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Delete(department depObject)
        {
            using (var db = new dbprojectengEntities())
            {
                department depItem = db.departments.Find(depObject.depid);
                db.departments.Remove(depItem);
                db.SaveChanges();
            }
        }
    }
}
