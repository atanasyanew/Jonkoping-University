﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Service.Mockups;
using Repository.EntityModels;

namespace Service.Models
{
    public class Employee
    {
        public int empid { get; set; }
        public string name { get; set; }
        public int depid { get; set; }
        public int salary { get; set; }

        static public Employee getEmployee(int empId)
        {
            return MapEmployee(EEmployee.dbGetEmployee(empId));
        }

        static public List<Employee> getEmployees()
        {
            List<Employee> empList = new List<Employee>();
            EEmployee.dbGetAllEmployeeList().ForEach(x => empList.Add(MapEmployee(x)));
            return empList;
        }

        static public List<Employee> getDepartmentEmployees(int depId)
        {
            List<Employee> empList = new List<Employee>();
            EEmployee.dbGetDepartmentEmployeeList(depId).ForEach(x => empList.Add(MapEmployee(x)));
            return empList; 
        }

        static private Employee MapEmployee(EEmployee empObj)
        {
            Employee theEmployee = new Employee();
            theEmployee.empid = empObj.EmpId;
            theEmployee.name = empObj.Name;
            theEmployee.depid = empObj.DepId;
            theEmployee.salary = empObj.Salary;
            return theEmployee;
        }
    }
}