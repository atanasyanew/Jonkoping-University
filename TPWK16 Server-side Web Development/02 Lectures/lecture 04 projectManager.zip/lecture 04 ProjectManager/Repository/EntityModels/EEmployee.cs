﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Repository.Repositories;

namespace Repository.EntityModels
{
    public class EEmployee
    {    
        private int _empid;
        private string _name;
        private int _depid;
        private int _salary;

        public int EmpId { get { return _empid; } set { _empid = value; } }
        public string Name { get { return _name; } set { _name = value; } }
        public int DepId { get { return _depid; } set { _depid = value; } }
        public int Salary { get { return _salary; } set { _salary = value; } }

        static public EEmployee dbGetEmployee(int id)
        {
            EEmployee _empObj = null;
            string _connectionString = DataSource.getConnectionString("projectmanager");
            SqlConnection con = new SqlConnection(_connectionString);
            SqlCommand cmd = new SqlCommand("SELECT * FROM employee WHERE empid = " + Convert.ToString(id) + ";", con);
            try
            {
                con.Open();
                SqlDataReader dar = cmd.ExecuteReader();
                if (dar.Read())
                {
                    _empObj = new EEmployee();
                    _empObj.DepId = (int)dar["empid"];
                    _empObj.Name = dar["name"] as string;
                    _empObj.DepId = (int)dar["depid"];
                    _empObj.Salary = (int)dar["salary"];
                }
            }
            catch (Exception eObj)
            {
                throw eObj;
            }
            finally
            {
                if (con != null)
                    con.Close();
            }
            return _empObj;
        }

        static private List<EEmployee> dbGetEmployeeList(string query)
        {
            List<EEmployee> _empList = null;
            string _connectionString = DataSource.getConnectionString("projectmanager");
            SqlConnection con = new SqlConnection(_connectionString);
            SqlCommand cmd = new SqlCommand(query, con);
            try
            {
                con.Open();
                SqlDataReader dar = cmd.ExecuteReader();
                if (dar != null)
                {
                    _empList = new List<EEmployee>();
                    while (dar.Read())
                    {
                        EEmployee empObj = new EEmployee();
                        empObj.EmpId = (int)dar["empid"];
                        empObj.Name = dar["name"] as string;
                        empObj.DepId = (int)dar["depid"];
                        empObj.Salary = (int)dar["salary"];
                        _empList.Add(empObj);
                    }
                }
            }
            catch (Exception eObj)
            {
                throw eObj;
            }
            finally
            {
                if (con != null)
                    con.Close();
            }
            return _empList;
        }

        static public List<EEmployee> dbGetAllEmployeeList()
        {
            return dbGetEmployeeList("SELECT * FROM employee;");
        }

        static public List<EEmployee> dbGetDepartmentEmployeeList(int depId)
        {
            return dbGetEmployeeList("SELECT * FROM employee WHERE depid = " + Convert.ToString(depId) + ";");
        }
    }
}
