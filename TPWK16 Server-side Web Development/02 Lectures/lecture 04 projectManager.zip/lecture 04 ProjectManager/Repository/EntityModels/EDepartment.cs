﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Repository.Repositories;

namespace Repository.EntityModels
{
    public class EDepartment
    {
        private int _depid;
        private string _name;
        private int _bossid;

        public int DepId { get { return _depid; } set { _depid = value; } }
        public string Name { get { return _name; } set { _name = value; } }
        public int BossId { get { return _bossid; } set { _bossid = value; } }

        static public EDepartment dbGetDepartment(int id)
        {
            EDepartment _depObj = null;
            string _connectionString = DataSource.getConnectionString("projectmanager");
            SqlConnection con = new SqlConnection(_connectionString);
            SqlCommand cmd = new SqlCommand("SELECT * FROM department WHERE depid = " + Convert.ToString(id) + ";", con);
            try
            {
                con.Open();
                SqlDataReader dar = cmd.ExecuteReader();
                if (dar.Read())
                {
                    _depObj = new EDepartment();
                    _depObj.DepId = Convert.ToInt32(dar["depid"]);
                    _depObj.Name = dar["name"] as string;
                    _depObj.BossId = Convert.ToInt32(dar["bossid"]);
                }
            }
            catch (Exception eObj)
            {
                throw eObj;
            }
            finally
            {
                if (con != null)
                    con.Close();
            }
            return _depObj;
        }

        static public List<EDepartment> dbGetDepartmentList()
        {
            List<EDepartment> _depList = null;
            string _connectionString = DataSource.getConnectionString("projectmanager");
            SqlConnection con = new SqlConnection(_connectionString);
            SqlCommand cmd = new SqlCommand("SELECT * FROM department where depid > 0;", con);
            try
            {
                con.Open();
                SqlDataReader dar = cmd.ExecuteReader();
                if (dar != null)
                {
                    _depList = new List<EDepartment>();
                    while (dar.Read())
                    {
                        EDepartment depObj = new EDepartment();
                        depObj.DepId = Convert.ToInt32(dar["depid"]);
                        depObj.Name = dar["name"] as string;
                        depObj.BossId = Convert.ToInt32(dar["bossid"]);
                        _depList.Add(depObj);
                    }
                }
            }
            catch (Exception eObj)
            {
                throw eObj;
            }
            finally
            {
                if (con != null)
                    con.Close();
            }
            return _depList;
        }

        static public int dbAddDepartment(EDepartment depObj)
        {
            int noOfRows = 0;
            string _connectionString = DataSource.getConnectionString("projectmanager");
            SqlConnection con = new SqlConnection(_connectionString);
//            SqlCommand cmd = new SqlCommand("INSERT INTO department values(" + depObj.DepId + ",'" + depObj.Name + "'," + depObj.BossId + ");", con);
            //An alternativ way of determining the depid is to embed a select query in the insert query. Select and insert will be treated as one transaction 
            SqlCommand cmd = new SqlCommand("INSERT INTO department values((SELECT MAX(depid)+1 FROM department),'" + depObj.Name + "'," + depObj.BossId + ");", con);
            try
            {
                con.Open();
                noOfRows = cmd.ExecuteNonQuery();
            }
            catch (Exception eObj)
            {
                throw eObj;
            }
            finally
            {
                if (con != null)
                    con.Close();
            }
            return noOfRows;
        }
    }
}
