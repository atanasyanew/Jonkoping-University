﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Service.Mockups;

namespace Service.Models
{
    public class Employee
    {
        public int empid { get; set; }
        public string name { get; set; }
        public int depid { get; set; }
        public int salary { get; set; }

        static public Employee getEmployee(int empId)
        {
            foreach (Employee emp in EmployeeMockup.employeeList)
            {
                if (emp.empid == empId)
                    return emp;
            }
            return null;
        }

        static public List<Employee> getEmployees()
        {
            return EmployeeMockup.employeeList;
        }

        static public List<Employee> getDepartmentEmployees(int depId)
        {
            List<Employee> empList = new List<Employee>();
            foreach(Employee emp in EmployeeMockup.employeeList)
            {
                if(emp.depid == depId)
                    empList.Add(emp);
            }
            return empList; 
        }
    }
}