use master;
go

/* Exchange DBxxxx with your database name, 4 places*/ 
IF (EXISTS (SELECT * from sysdatabases WHERE name = 'DBxxxx'))
BEGIN
	DROP DATABASE DBxxxx
END
GO

IF (NOT EXISTS (SELECT * from sysdatabases WHERE name = 'DBxxxx'))
BEGIN
	CREATE DATABASE DBxxxx
END
