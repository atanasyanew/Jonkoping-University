﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProjectManager.Models;

namespace ProjectManager.Controllers
{
    public class UserListsController : Controller
    {

        static private List<Department> departmentList = new List<Department>
        {
            new Department {depid = 1,name="administration",bossid = 106},
            new Department {depid = 2,name="Manufacturing",bossid = 104},
            new Department {depid = 3,name="Advertisement",bossid = 107}
        };

        public ActionResult ListDepartments()
        {
            return View("TheListOfDepartments", departmentList);
        }

        [HttpGet]
        public ActionResult AddDepartment()
        {
            Department depObj = new Department();
            return View(depObj);
        }

        [HttpPost]
        public ActionResult AddDepartment(Department depObj)
        {
            return View("ShowDepartment", depObj);
        }

	}
}