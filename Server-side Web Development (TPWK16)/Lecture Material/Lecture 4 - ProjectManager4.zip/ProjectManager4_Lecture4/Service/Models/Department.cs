﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Service.Mockups;
using Repository.EntityModels;

namespace Service.Models
{
    public class Department
    {
        public int depid { get; set; }
        public string name {get; set;}
        public int bossid {get; set;}

        static public Department getDepartment(int depId)
        {
            return MapDepartment(EDepartment.dbGetDepartment(depId));
        }

        static public List<Department> getDepartments()
        {
            List<Department> depList = new List<Department>();
/*            
            foreach (EDepartment edep in EDepartment.dbGetDepartmentList())
            {
                depList.Add(MapDepartment(edep));
            }
*/
            EDepartment.dbGetDepartmentList().ForEach(x => depList.Add(MapDepartment(x)));
            return depList;
        }

        static public List<Employee> getDepartmentEmployees(int depId)
        { 
            return Employee.getDepartmentEmployees(depId); 
        }

        static public void addDepartment(Department depObj)
        {
            //You might calculate the new depid here or push it further down into the repository
/*            List<Department> depList = Department.getDepartments();
            depObj.depid = depList.Max(x => x.depid) + 1; */

            EDepartment.dbAddDepartment(MapDepartment(depObj));
        }

        static public Department MapDepartment(EDepartment depObj)
        {
            Department theDepartment = new Department();
            theDepartment.depid = depObj.DepId;
            theDepartment.name = depObj.Name;
            theDepartment.bossid = depObj.BossId;
            return theDepartment;
        }

        static public EDepartment MapDepartment(Department DepObj)
        {
            EDepartment theDepartment = new EDepartment();
            theDepartment.DepId = DepObj.depid;
            theDepartment.Name = DepObj.name;
            theDepartment.BossId = DepObj.bossid;
            return theDepartment;
        }

    }
}