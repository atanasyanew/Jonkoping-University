﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Models
{
    public class DepartmentBoss:Department
    {
        public string bossName { get; set; }
        public int salary { get; set; }
    }
}