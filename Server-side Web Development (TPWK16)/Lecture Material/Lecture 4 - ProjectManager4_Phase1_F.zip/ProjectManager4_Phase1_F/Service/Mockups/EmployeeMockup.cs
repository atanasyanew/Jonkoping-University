﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Service.Models;

namespace Service.Mockups
{
    class EmployeeMockup
    {
        static public List<Employee> employeeList = new List<Employee>
        {
            new Employee {empid = 101, name = "Hanna Larsson", depid = 1, salary = 38000},
            new Employee {empid = 102, name = "Stefan Karlsson", depid = 1, salary = 37000},
            new Employee {empid = 106, name = "Erik Fransson", depid = 1, salary = 51000},
            new Employee {empid = 103, name = "Bo Ek", depid = 2, salary = 43000},
            new Employee {empid = 104, name = "Catarina Klurig", depid = 2, salary = 58000},
            new Employee {empid = 105, name = "Kurre Lustig", depid = 2, salary = 36000},
            new Employee {empid = 108, name = "Sven Lustig", depid = 2, salary = 35000},
            new Employee {empid = 107, name = "Cecilia Hurtig", depid = 3, salary = 49000},
            new Employee {empid = 109, name = "Erik Svantesson", depid = 3, salary = 33000}

        };
    }
}
