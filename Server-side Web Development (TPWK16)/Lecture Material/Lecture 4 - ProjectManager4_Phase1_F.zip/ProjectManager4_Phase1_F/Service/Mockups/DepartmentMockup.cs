﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Service.Models;

namespace Service.Mockups
{
    class DepartmentMockup
    {
        static public List<Department> departmentList = new List<Department>
        {
            new Department {depid = 1, name = "Administration", bossid = 106},
            new Department {depid = 2, name = "Manufactoring", bossid = 104},
            new Department {depid = 3, name = "Advertisement", bossid = 107}
        };
    }
}
