﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Service.Mockups;

namespace Service.Models
{
    public class Department
    {
        public int depid { get; set; }
        public string name {get; set;}
        public int bossid {get; set;}

        static public Department getDepartment(int depId)
        {
            foreach (Department dep in DepartmentMockup.departmentList)
            {
                if (dep.depid == depId)
                    return dep;
            }
            return null;
        }

        static public List<Department> getDepartments()
        {
            return DepartmentMockup.departmentList;
        }

        static public List<Employee> getDepartmentEmployees(int depId)
        { 
            return Employee.getDepartmentEmployees(depId); 
        }
    }
}