﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.EntityModel
{
    class E_Department
    {
        public class department
        {
            private int _depid;
            private string _name;
            private int _bossid;

            public int DepId { get { return _depid; } set { _depid = value; } }
            public string Name { get { return _name; } set { _name = value; } }
            public int BossId { get { return _bossid; } set { _bossid = value; } }
        }
    }
}
