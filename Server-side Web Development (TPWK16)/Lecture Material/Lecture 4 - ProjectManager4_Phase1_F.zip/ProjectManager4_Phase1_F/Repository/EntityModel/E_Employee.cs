﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.EntityModel
{
    class E_Employee
    {    
        private int _empid;
        private string _name;
        private int _depid;
        private int _salary;

        public int EmpId { get { return _empid; } set { _empid = value; } }
        public string Name { get { return _name; } set { _name = value; } }
        public int DepId { get { return _depid; } set { _depid = value; } }
        public int Salary { get { return _salary; } set { _salary = value; } }
    }
}
