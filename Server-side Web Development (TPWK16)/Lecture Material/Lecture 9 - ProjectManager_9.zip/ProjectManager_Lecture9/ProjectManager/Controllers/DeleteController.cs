﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Service.Models;

namespace ProjectManager.Controllers
{
    public class DeleteController : Controller
    {
        public ActionResult DeleteObject(string select, string selectid)
        {
            switch (select)
            {
                case "11": //Edit department
                    Session["DepartmentId"] = Convert.ToInt32(selectid);
                    return RedirectToAction("DeleteDepartment");
                case "12": //Edit employee
                    Session["EmployeeId"] = Convert.ToInt32(selectid);
                    return RedirectToAction("DeleteEmployee");
                case "13": // Edit project
                    return RedirectToAction("DeleteProject");
                default:
                    ViewBag.Error = "Could not perform the delete action";
                    break;
            }
            return View("Error");
        }

        /**************************** Department methods  **************************/
        public RedirectToRouteResult DeleteDepartment()
        {
            Department.deleteDepartment(Department.getDepartment((int)Session["DepartmentId"]));
            return RedirectToAction("ListDepartments", "UserLists");
        }

        /**************************** Employee methods  ****************************/
        public ActionResult DeleteEmployee()
        {
            if (Employee.deleteEmployee(Employee.getEmployee((int)Session["EmployeeId"])))
            {
                return RedirectToAction("ListEmployee", "UserLists");
            }
            else
            {
                ViewBag.Error = "Could not delete employee! Check if employee is department manager.";
                return View("Error");
            }
        }

        /**************************** Project methods  *****************************/
        public ActionResult DeleteProject()
        {
            return View();
        }


	}
}