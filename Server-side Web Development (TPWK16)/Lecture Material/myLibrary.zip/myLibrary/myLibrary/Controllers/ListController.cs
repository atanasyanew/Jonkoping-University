﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Service.Models;

namespace myLibrary.Controllers
{
    public class ListController : Controller
    {
        //
        // GET: /List/
        public ActionResult Index()
        {
//            return RedirectToAction("AuthorDetails");
//            return RedirectToAction("BookDetails");
            return View();
        }

        public ActionResult AuthorDetails()
        {
            int authorId = 720; //638, 720, 773

            return View(Author.getAuthor(authorId));
        }

        public ActionResult BookDetails()
        {
            string isbn = "9144384416";  //9144384416, 0830643273, 410218, 44168411

            return View(Book.getBook(isbn));
        }

        public ActionResult AddBookAuthor()
        {
            Book.AddBookAuthor();
            return View("Index");
        }
	}
}