﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;           //Denna måste vara med!!!

namespace Repository.Support
{
    public class BookDba
    {
        public BookDba() { }

        private BOOK _bookObj;

        public BOOK readWithAuthorList(string isbn)
        {
            using (var db = new DBLibraryEntities())
            {
                _bookObj = db.BOOKs.Include(x => x.AUTHORs).ToList().Find(b => b.ISBN == isbn);
            }
            return _bookObj;
        }

        public void addBookAuthor(BOOK aBook, AUTHOR anAuthor)
        {
            using (var db = new DBLibraryEntities())
            {
                //Add book and author
                db.AUTHORs.Add(anAuthor);
                db.BOOKs.Add(aBook);
                //Add the references in intermediate table
                aBook.AUTHORs.Add(anAuthor);  //EF will do the rest

                db.SaveChanges();
            }
        }

        public void addExistingBookAuthor(string bookId, int authorid)
        {

        }
    }
}
