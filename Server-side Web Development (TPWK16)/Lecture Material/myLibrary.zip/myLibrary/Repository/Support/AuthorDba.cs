﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Repository;

namespace Repository.Support
{
    public class AuthorDba 
    {
        public AuthorDba() { }

        public AuthorDba(int aid) 
        {
            _authorObj = this.read(aid); 
        }

        private AUTHOR _authorObj;

        public AUTHOR read(int aid)
        {
            using (var db = new DBLibraryEntities())
            {
                //Using lazy loading, related list of books is not loaded unless used
                db.AUTHORs.Load();
                return db.AUTHORs.Find(aid);
            }
        }

        public AUTHOR readWithBookList(int aid)
        {
            using (var db = new DBLibraryEntities())
            {
//                var query = from d in db.AUTHORs where d.Aid == aid select d;

                //Using lazy loading, related list of books is not loaded unless used
//               _authorObj = query.Single();
//                if(_authorObj.BOOKs != null) { } //Do something for lazyload to be activated 
                
                //Using eager loading
                _authorObj = db.AUTHORs.Include(a => a.BOOKs).ToList().Find(x => x.Aid == aid);  //A variant
/*                query = query.Include(a => a.BOOKs);
                _authorObj = query.Single(); */

                //Using explicit loading
/*                _authorObj = query.Single();
                db.Entry(_authorObj).Collection(x => x.BOOKs).Load();  */

            }
            return _authorObj;
        }

        public List<AUTHOR> List()
        {

            using (var db = new DBLibraryEntities())
            {
                //var query = db.AUTHORs.OrderBy(x => x.LastName);
                //return query.ToList();
                return db.AUTHORs.ToList();
            }
        }

    }
}
/*
                db.BOOKs.ToList();
                var count = db.BOOKs.Local.Count;
                _authorObj.BOOKs = new List<BOOK>();
                db.BOOKs.Local.ToList().ForEach(x => )  */
//                _authorObj.BOOKs.Add(db.BOOKs.Local.ToList());
/*                _authorObj.BOOKs = (
                    from a in db.AUTHORs
                    from b in a.BOOKs
                    join c in db.BOOKs on b.ISBN equals c.ISBN
                    where a.Aid == aid
                    select new BOOK
                    {
                        ISBN = c.ISBN,
                        Title = c.Title,
                        SignId = c.SignId,
                        PublicationYear = c.PublicationYear,
                        publicationinfo = c.publicationinfo,
                        pages = c.pages,
                        CLASSIFICATION = null,
                        COPies = null,
                        AUTHORs = null
                    }).ToList();
 */