﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Infrastructure;

    public partial class DBLibraryEntities : DbContext
    {
        static DBLibraryEntities()
        {
            var foo = System.Data.Entity.SqlServer.SqlProviderServices.Instance;
        }
    }
}
