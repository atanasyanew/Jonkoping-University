﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Repository;
using Repository.Support;
using AutoMapper;
using Service.Configuration;

namespace Service.Models
{
    public class Author
    {
        public int aid {get; set;}
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string birthYear { get; set; }
        public int noOfBooks { get; set; }   //An extra attribute to demo Automapper function

        public List<Book> books { get; set; }

        static private AuthorDba _authorDba = new AuthorDba();

        static public Author getAuthor(int aId)
        {
//            List<BOOK> test = _authorDba.read(aId).BOOKs.ToList();
//            List<BOOK> test = _authorDba.readWithBookList(aId).BOOKs.ToList();
            return Mapper.Map<Author>(_authorDba.readWithBookList(aId));

/* //This is an alternative solution
            AUTHOR anAUTHORobj = _authorDba.readWithBookList(aId);
            Author authorObj = Mapper.Map<Author>(anAUTHORobj);
            authorObj.books = Mapper.Map<List<BOOK>, List<Book>>(anAUTHORobj.BOOKs.ToList());
            return authorObj;
*/
        }

        static public List<Author> getAuthorList()
        {
            return null;
        }
    }
}
