﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Repository;
using Repository.Support;
using AutoMapper;
using Service.Configuration;

namespace Service.Models
{
    public class Book
    {
        public string isbn { get; set; }
        public string title { get; set; }
        public Nullable<int> signId { get; set; }
        public string publicationYear { get; set; }
        public string publicationInfo { get; set; }
        public Nullable<short> pages { get; set; }

        public List<Author> Authors { get; set; }

        private static BookDba _bookDbObj = new BookDba();

        public static Book getBook(string isbn)
        {
            BOOK aBOOKobj = _bookDbObj.readWithAuthorList(isbn);
            Book bookObj = Mapper.Map<Book>(aBOOKobj);    //Does not map Authorlist due to AutoMapper configuration
//            bookObj.Authors = Mapper.Map<List<AUTHOR>, List<Author>>(aBOOKobj.AUTHORs.ToList());  //Loading the AuthorList
            return bookObj;
        }

        public static void AddBookAuthor()
        {
            Author anAuthorObj = new Author { firstName = "Jo", lastName = "Hill", birthYear = "1856" };
            Book aBookObj = new Book { isbn = "123456789X", title = "How to climb a Hill", signId = null, publicationYear = "1945", publicationInfo = "Daily News publition company", pages = 1024 };

            _bookDbObj.addBookAuthor(Mapper.Map<BOOK>(aBookObj), Mapper.Map<AUTHOR>(anAuthorObj));
        }
    }
}
