﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Service.Models;
using Repository;

namespace Service.Configuration
{
    
    public static class AutoMapperConfig
    {
        public static void Configure()
        {
            Mapper.Initialize(cfg =>
                {
                    cfg.AddProfile(new ToAuthorProfile());
                    cfg.AddProfile(new FromAuthorProfile());
                    cfg.AddProfile(new ToBookProfile());
                    cfg.AddProfile(new FromBookProfile());
                }
            );
        }
    }

    public class ToAuthorProfile : Profile
    {
        public ToAuthorProfile()
        {
            CreateMap<AUTHOR, Author>().
                //                ForMember(m => m.books, opt => opt.Ignore()).
                AfterMap((src, dest) => dest.noOfBooks = src.BOOKs.ToList().Count);
//                ForMember(m => m.books, opt => opt.MapFrom(src => src.BOOKs));

        }
    }

    public class FromAuthorProfile : Profile
    {
        public FromAuthorProfile()
        {
            CreateMap<Author, AUTHOR>();
        }
    }

    public class ToBookProfile : Profile
    {
        public ToBookProfile()
        {
            CreateMap<BOOK, Book>().
                ForMember(m => m.Authors, opt => opt.Ignore()); //Prevents loading of Authors-list
        }
    }

    public class FromBookProfile : Profile
    {
        public FromBookProfile()
        {
            CreateMap<Book, BOOK>();
        }
    }
    
}
