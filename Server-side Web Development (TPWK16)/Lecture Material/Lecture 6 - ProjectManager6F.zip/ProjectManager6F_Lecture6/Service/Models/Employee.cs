﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Service.Mockups;
using Repository;
using Repository.Support;
using AutoMapper;

namespace Service.Models
{
    public class Employee
    {
        public int empid { get; set; }
        public string name { get; set; }
        public int? depid { get; set; }
        public int salary { get; set; }

        static private EmployeeDba _employeeDba = new EmployeeDba();


        static public Employee getEmployee(int empId)
        {
            return Mapper.Map<Employee>(_employeeDba.Read(empId));
        }

        static public List<Employee> getEmployees()
        {
            return Mapper.Map < List < employee > ,List < Employee >> (_employeeDba.List());
        }

        static public List<Employee> getDepartmentEmployees(int depId)
        {
            return Mapper.Map<List<employee>, List<Employee>>(_employeeDba.ReadDepEmp(depId));
        }

        static public void nullifyDepartmentRef(Department depObj)
        {
            List<Employee> empList = Employee.getDepartmentEmployees(depObj.depid);
            empList.ForEach(x => x.depid = null);
            empList.ForEach(x => _employeeDba.Update(Mapper.Map<employee>(x)));
        }

        static public void addEmployee(Employee empObj)
        {
            _employeeDba.Add(Mapper.Map<employee>(empObj));
        }

        static public void updateemployee(Employee empObj)
        {
            _employeeDba.Update(Mapper.Map<employee>(empObj));
        }

        static public void deleteEmployee(Employee empObj)
        {
            /* 
             * Deletion of employee requires to resolve one issue:
             * Department manager has a reference to a department, (foreign key bossid in Department table)
            */
            Department.nullifyEmployeeRef(empObj);
            _employeeDba.Delete(Mapper.Map<employee>(empObj));
        }

    }
}