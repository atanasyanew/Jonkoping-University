﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Service.Mockups;
using Repository;
using Repository.Support;
using AutoMapper;
using Service.Configuration;

namespace Service.Models
{
    public class Department
    {
        public int depid { get; set; }
        public string name {get; set;}
        public int? bossid {get; set;}

        static private DepartmentDba _departmentDba = new DepartmentDba(); 

        static public Department getDepartment(int depId)
        {
            return Mapper.Map<Department>(_departmentDba.Read(depId));
        }

        static public List<Department> getDepartments()
        {
            return Mapper.Map<List<department>, List<Department>>( _departmentDba.List());
        }

        static public List<Employee> getDepartmentEmployees(int depId)
        {
            return Employee.getDepartmentEmployees(depId);
        }

        static public void nullifyEmployeeRef(Employee empObj)
        {
            Department depObj = getDepartment((int) empObj.depid);
            depObj.bossid = null;
            _departmentDba.Update(Mapper.Map<department>(depObj));
        }

        static public void addDepartment(Department depObj)
        {
            _departmentDba.Add(Mapper.Map<department>(depObj));
        }

        static public void updateDepartment(Department depObj)
        {
            _departmentDba.Update(Mapper.Map<department>(depObj));
        }

        static public void deleteDepartment(Department depObj)
        {
            /* 
             * Deletion of department requires to resolve one issue:
             * People belonging to that department, (foreign key depid in Employee table)
            */
            Employee.nullifyDepartmentRef(depObj);
            _departmentDba.Delete(Mapper.Map<department>(depObj));
        }
    }
}