﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Service.Models;

namespace ProjectManager.Controllers
{
    public class EditController : Controller
    {
        public ActionResult EditObject(string select, string selectid)
        {
            switch (select)
            {
                case "11": //Edit department
                    TempData["DepartmentId"] = Convert.ToInt32(selectid);
                    return RedirectToAction("EditDepartment");
                case "12": //Edit employee
                    return RedirectToAction("EditEmployee");
                case "13": // Edit project
                    return RedirectToAction("EditProject");
                default:
                    ViewBag.Error = "Could not perform the edit action";
                    break;
            }
            return View("Error");
        }

        /**************************** Department methods  **************************/
        public ViewResult EditDepartment()
        {
            Department depObj = Department.getDepartment((int)TempData["DepartmentId"]);
            ViewBag.EmployeeList = Department.getDepartmentEmployees(depObj.depid);
            return View(depObj);
        }

        [HttpPost]
        public RedirectToRouteResult EditDepartment(Department depObj)
        {
            return RedirectToAction("StoreDepartment", depObj);
        }

        public RedirectToRouteResult StoreDepartment(Department depObj)
        {
            Department.updateDepartment(depObj);
            return RedirectToAction("ListDepartments", "UserLists");
        }

        /**************************** Employee methods  ****************************/
        public ActionResult EditEmployee()
        {
            return View();
        }

        /**************************** Project methods  *****************************/
        public ActionResult EditProject()
        {
            return View();
        }
	}
}