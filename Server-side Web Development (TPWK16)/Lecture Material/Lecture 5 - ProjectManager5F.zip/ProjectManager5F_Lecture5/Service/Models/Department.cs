﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Service.Mockups;
using Repository.Support;

namespace Service.Models
{
    public class Department
    {
        public int depid { get; set; }
        public string name {get; set;}
        public int bossid {get; set;}

        static public Department getDepartment(int depId)
        {
            DepartmentDba depDbaObj = new DepartmentDba(depId);
            Department depObj = new Department();
            depObj.depid = depDbaObj.DepartmentObj.depid;
            depObj.bossid = (int) depDbaObj.DepartmentObj.bossid;
            depObj.name = depDbaObj.DepartmentObj.name;
            return depObj;
        }

        static public List<Department> getDepartments()
        {
            DepartmentDba depDbaObj = new DepartmentDba();
            List<Department> depObjList = new List<Department>();
            foreach (var elem in depDbaObj.List())
            {
                Department depObj = new Department();
                depObj.depid = (int) elem.depid;
                depObj.bossid = (int) elem.bossid;
                depObj.name = (string) elem.name;
                depObjList.Add(depObj);
            }

            return depObjList;
        }

        static public List<Employee> getDepartmentEmployees(int depId)
        { 
            return Employee.getDepartmentEmployees(depId); 
        }
    }
}