﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Service.Mockups;
using Repository.Support;

namespace Service.Models
{
    public class Employee
    {
        public int empid { get; set; }
        public string name { get; set; }
        public int depid { get; set; }
        public int salary { get; set; }

        static public Employee getEmployee(int empId)
        {
            EmployeeDba empDbaObj = new EmployeeDba(empId);
            Employee empObj = new Employee();
            empObj.empid = (int) empDbaObj.EmployeeObj.empid;
            empObj.depid = (int)empDbaObj.EmployeeObj.depid;
            empObj.name = (string) empDbaObj.EmployeeObj.name;
            empObj.salary = (int) empDbaObj.EmployeeObj.salary;
            return empObj;
        }

        static public List<Employee> getEmployees()
        {
            EmployeeDba empDbaObj = new EmployeeDba();
            List<Employee> empObjList = new List<Employee>();
            foreach (var elem in empDbaObj.List())
            {
                Employee empObj = new Employee();
                empObj.empid = (int)elem.empid;
                empObj.depid = (int)elem.depid;
                empObj.name = (string)elem.name;
                empObj.salary = (int)elem.salary;
                empObjList.Add(empObj);
            }

            return empObjList;
        }

        static public List<Employee> getDepartmentEmployees(int empId)
        {
            EmployeeDba empDbaObj = new EmployeeDba();
            List<Employee> empList = new List<Employee>();
            foreach (var emp in empDbaObj.List())
            {
                if(emp.empid == empId)
                {
                    Employee empObj = new Employee();
                    empObj.empid = (int)emp.empid;
                    empObj.depid = (int)emp.depid;
                    empObj.name = (string)emp.name;
                    empObj.salary = (int)emp.salary;
                    empList.Add(empObj);
                }
            }
            return empList; 
        }
    }
}