﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using ProjectManager.Models;
using Service.Models;

namespace ProjectManager.Controllers
{
    public class UserListsController : Controller
    {

        public ViewResult ListDepartments()
        {
            return View("TheListOfDepartments", Department.getDepartments());
        }

        public ViewResult AddDepartment()
        {
            Department depObj = new Department();
            return View(depObj);
        }

       [HttpPost]
        public RedirectToRouteResult AddDepartment(Department depObj)
        {
            TempData["DepartmentObject"] = depObj;
            return RedirectToAction("ShowDepartment");
        }

        public ActionResult ShowDepartment()
        {
            Department depObj = (Department) TempData["DepartmentObject"];
            return View(depObj);
        }

        //Using the combined class DepartmentBoss and a strongly typed view
        public ActionResult ShowDepartmentAndBoss(string bossid, string depid)
        {
            Employee empObj = Employee.getEmployee(Convert.ToInt32(bossid));
            Department depObj = Department.getDepartment(Convert.ToInt32(depid));
            if (empObj != null && depObj != null)
            {
                DepartmentBoss depBossObj = new DepartmentBoss { depid = depObj.depid, name = depObj.name, bossid = depObj.bossid, bossName = empObj.name, salary = empObj.salary};
                return View(depBossObj);
            }            
            return null;
        }

        //Alternativ using to strongly typed partial views
        public ActionResult ShowDepartmentAndBossSecond(string bossid, string depid)
        {
            ViewBag.Departmentid = depid;
            ViewBag.Employeeid = bossid;
            List<Employee> departmentEmployeeList = Department.getDepartmentEmployees(Convert.ToInt32(depid));
            return View(departmentEmployeeList);
        }

        [ChildActionOnly]
        public ActionResult ShowDepartmentPartial(string depid)
        {
            Department depObj = Department.getDepartment(Convert.ToInt32(depid));
            if (depObj != null)
                return PartialView(depObj);
            return null;
        }

        [ChildActionOnly]
        public ActionResult ShowEmployeePartial(string empid)
        {
            Employee empObj = Employee.getEmployee(Convert.ToInt32(empid));
            if (empObj != null)
                return PartialView(empObj);
            return null;
        }

        public ActionResult ListEmployee()
        {
            return View(Employee.getEmployees());
        }

        public ActionResult AddEmployee()
        {
            return View();
        }
  	}

}