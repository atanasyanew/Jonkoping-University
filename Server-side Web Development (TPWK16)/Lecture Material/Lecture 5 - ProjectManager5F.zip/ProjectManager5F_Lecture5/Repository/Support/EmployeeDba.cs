﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;  //Required for the update method

namespace Repository.Support
{
    public class EmployeeDba
    {
        //Added for manual mapping between Entity classes and View model classes
        public EmployeeDba() { }

        public EmployeeDba(int depId)
        {
            _employeeObj = this.Read(depId);
        }

        private employee _employeeObj;

        public employee EmployeeObj { get { return _employeeObj; } }
        // ----------------------

        public List<employee> List()
        {
            using (var db = new dbprojectengEntities())
            {
                return db.employees.ToList();
            }
        }

        public employee Read(int id)
        {
            using (var db = new dbprojectengEntities())
            {
                return db.employees.Find(id);
            }
        }
        /*
        void Add(employee depObject);
        void Update(employee depObject);
        void Delete(employee depObject);
        */
    }
}
