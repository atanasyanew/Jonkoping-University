﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;  //Required for the update method

namespace Repository.Support
{
    public class DepartmentDba
    {
        //Added for manual mapping between Entity classes and View model classes
        public DepartmentDba() { }

        public DepartmentDba(int depId)
        {
            _departmentObj = this.Read(depId);
        }

        private department _departmentObj;

        public department DepartmentObj { get { return _departmentObj;} }
        // ----------------

        public List<department> List()
        {
            using(var db = new dbprojectengEntities())
            {
                return db.departments.ToList();
            }
        }

        public department Read(int id)
        {
            using (var db = new dbprojectengEntities())
            {
                return db.departments.Find(id); //Finds a particular "department"
            }
        }

        public void Add(department depObject)
        {
            using (var db = new dbprojectengEntities())
            {
                db.departments.Add(depObject);   //Adds the change to a transaction to be run
                db.SaveChanges();   //Runs the transaction
            }
        }

        public void Update(department depObject)
        {
            using (var db = new dbprojectengEntities())
            {
                db.departments.Attach(depObject);
                db.Entry(depObject).State = EntityState.Modified;
                db.SaveChanges();
            }
        }

        public void Delete(department depObject)
        {
            using (var db = new dbprojectengEntities())
            {
                department depItem = db.departments.Find(depObject.depid);
                db.departments.Remove(depItem);
                db.SaveChanges();
            }
        }
    }
}
