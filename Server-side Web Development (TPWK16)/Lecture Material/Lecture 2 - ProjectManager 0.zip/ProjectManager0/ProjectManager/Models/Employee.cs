﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectManager.Models
{
    public class Employee
    {
        public int empid { get; set; }
        public string name { get; set; }
        public int depid { get; set; }
        public int salary { get; set; }
    }
}