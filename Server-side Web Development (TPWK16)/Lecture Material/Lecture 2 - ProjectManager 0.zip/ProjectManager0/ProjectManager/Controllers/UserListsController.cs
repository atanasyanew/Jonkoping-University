﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProjectManager.Models;

namespace ProjectManager.Controllers
{
    public class UserListsController : Controller
    {
        static private List<Department> departmentList = new List<Department>
        {
            new Department {depid = 1, name = "Administration", bossid = 106},
            new Department {depid = 2, name = "Manufactoring", bossid = 104},
            new Department {depid = 3, name = "Advertisement", bossid = 107}
        };
        static private List<Employee> employeeList = new List<Employee>
        {
            new Employee {empid = 101, name = "Hanna Larsson", depid = 1, salary = 38000},
            new Employee {empid = 102, name = "Stefan Karlsson", depid = 1, salary = 37000},
            new Employee {empid = 106, name = "Erik Fransson", depid = 1, salary = 51000},
            new Employee {empid = 103, name = "Bo Ek", depid = 2, salary = 43000},
            new Employee {empid = 104, name = "Catarina Klurig", depid = 2, salary = 51000},
            new Employee {empid = 105, name = "Kurre Lustig", depid = 2, salary = 35000},
            new Employee {empid = 108, name = "Sven Lustig", depid = 2, salary = 35000},
            new Employee {empid = 107, name = "Cecilia Hurtig", depid = 3, salary = 51000},
            new Employee {empid = 109, name = "Erik Svantesson", depid = 3, salary = 33000}

        };

        public ViewResult ListDepartments()
        {
//            return View(departmentList);
            return View("TheListOfDepartments",departmentList);
        }

        public ViewResult AddDepartment()
        {
            Department depObj = new Department();
            return View(depObj);
        }

 //       [HttpPost]
//        public ViewResult AddDepartment(Department depObj)
//        {
////            ViewBag.department = depObj;
//            return View("ShowDepartment",depObj);
//        }
        [HttpPost]
        public RedirectToRouteResult AddDepartment(Department depObj)
        {
            TempData["DepartmentObject"] = depObj;
            return RedirectToAction("ShowDepartment");
        }

        public ActionResult ShowDepartment()
        {
            Department depObj = (Department) TempData["DepartmentObject"];
            return View(depObj);
        }

        public ActionResult ShowDepartmentAndBoss(string bossid, string depid)
        {
            Employee empObj = employeeList.Find(x => x.empid == Convert.ToInt32(bossid));
/*
            Employee empObj = null;
            foreach (Employee emp in employeeList)
            {
                if (emp.empid == Convert.ToInt32(bossid))
                    empObj = emp;
            }
*/
            Department depObj = departmentList.Find(x => x.depid == Convert.ToInt32(depid));

            if (empObj != null && depObj != null)
            {
                DepartmentBoss depBossObj = new DepartmentBoss { depid = depObj.depid, name = depObj.name, bossid = depObj.bossid, bossName = empObj.name, salary = empObj.salary};
                return View(depBossObj);
            }            
            return null;
        }

        public ActionResult ShowDepartmentAndBossSecond(string bossid, string depid)
        {
            ViewBag.Departmentid = depid;
            ViewBag.Employeeid = bossid;
            return View();
        }

        [ChildActionOnly]
        public ActionResult ShowDepartmentPartial(string depid)
        {
            Department depObj = departmentList.Find(x => x.depid == Convert.ToInt32(depid));
            if (depObj != null)
                return PartialView(depObj);
            return null;
        }

        [ChildActionOnly]
        public ActionResult ShowEmployeePartial(string empid)
        {
            Employee empObj = employeeList.Find(x => x.empid == Convert.ToInt32(empid));
            if (empObj != null)
                return PartialView(empObj);
            return null;
        }

        public ActionResult ListEmployee()
        {
            return View(employeeList);
        }

        public ActionResult AddEmployee()
        {
            return View();
        }
  	}

}